INSERT INTO Customers (customerID, companyName, contactName, contactTitle)
SELECT DISTINCT customerID, companyName, contactName, contactTitle
FROM Cleaned_Northwind_Sales;

INSERT INTO Employees (employeeID, lastName, firstName, title)
SELECT DISTINCT employeeID, employees_lastName, employees_firstName, employees_title FROM Cleaned_Northwind_Sales;

INSERT INTO Orders (orderID, orderDate, requiredDate, shippedDate, shipVia, freight, customerID, employeeID)
SELECT DISTINCT orderID, orderDate, requiredDate, shippedDate, shipVia, Freight, customerID, employeeID
FROM�Cleaned_Northwind_Sales;

WITH UniqueSuppliers AS (
    SELECT 
        supplierID,
        suppliers_companyName,
        suppliers_contactName,
        suppliers_contactTitle,
        ROW_NUMBER() OVER (PARTITION BY supplierID ORDER BY supplierID) AS RowNum
    FROM Cleaned_Northwind_Sales
)
INSERT INTO Suppliers (supplierID, companyName, contactName, contactTitle)
SELECT supplierID, suppliers_companyName, suppliers_contactName, suppliers_contactTitle
FROM UniqueSuppliers
WHERE RowNum = 1;


WITH UniqueCategories AS (
    SELECT 
        categoryID,
        categoryName,
        ROW_NUMBER() OVER (PARTITION BY categoryID ORDER BY categoryID) AS RowNum
    FROM Cleaned_Northwind_Sales
)
INSERT INTO Categories (categoryID, categoryName)
SELECT categoryID, categoryName
FROM UniqueCategories
WHERE RowNum = 1
  AND categoryID NOT IN (SELECT categoryID FROM Categories);



 INSERT INTO Products (productID, productName, supplierID, categoryID, quantityPerUnit, unitPrice_1, unitsInStock, unitsOnOrder, reorderLevel, discontinued)
SELECT DISTINCT productID, productName, supplierID, categoryID, quantityPerUnit, unitPrice_1, unitsInStock, unitsOnOrder, reorderLevel, discontinued
FROM Cleaned_Northwind_Sales;


INSERT INTO OrderDetails (orderID, productID, unitPrice, quantity, discount)
SELECT DISTINCT orderID, productID, unitPrice, quantity, discount
FROM Cleaned_Northwind_Sales
