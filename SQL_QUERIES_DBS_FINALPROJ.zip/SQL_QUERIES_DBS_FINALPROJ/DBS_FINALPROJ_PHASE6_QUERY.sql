-- Step 1: Create a login for the Database Administrator
CREATE LOGIN AlexSmith
WITH PASSWORD = 'AlexSmith123';

-- Step 2: Create a user for the Database Administrator in the database
USE Proj_final_1;  -- Replace with the name of your database
CREATE USER AlexSmith FOR LOGIN AlexSmith;

-- Step 3: Grant full database administrator privileges
EXEC sp_addrolemember 'db_owner', 'AlexSmith';


-- Step 1: Create a login for the Data Analyst
CREATE LOGIN JamieLee
WITH PASSWORD = 'JamieLee123';

-- Step 2: Create a user for the Data Analyst in the database
USE Proj_final_1;  -- Replace with the name of your database
CREATE USER JamieLee FOR LOGIN JamieLee;

-- Step 3: Grant read-only access
EXEC sp_addrolemember 'db_datareader', 'JamieLee';
