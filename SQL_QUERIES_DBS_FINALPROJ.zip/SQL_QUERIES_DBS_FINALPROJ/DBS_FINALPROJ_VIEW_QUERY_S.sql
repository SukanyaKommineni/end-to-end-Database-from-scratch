CREATE VIEW EmployeeSales AS
SELECT 
    e.employeeID,
    CONCAT(e.firstName, ' ', e.lastName) AS employeeName,
    SUM(od.quantity) AS totalQuantitySold,
    SUM(od.quantity * od.unitPrice * (1 - od.discount)) AS totalRevenue
FROM 
    Employees e
JOIN 
    Orders o ON e.employeeID = o.employeeID
JOIN 
    OrderDetails od ON o.orderID = od.orderID
GROUP BY 
    e.employeeID, e.firstName, e.lastName;
