-- Customers Table
CREATE TABLE Customers (
    customerID VARCHAR(50) PRIMARY KEY,
    companyName VARCHAR(50),
    contactName VARCHAR(50),
    contactTitle VARCHAR(50)
);

-- Employees Table
CREATE TABLE Employees (
    employeeID INT PRIMARY KEY,
    lastName VARCHAR(50),
    firstName VARCHAR(50),
    title VARCHAR(50)
);

-- Orders Table
CREATE TABLE Orders (
    orderID INT PRIMARY KEY,
    orderDate DATE,
    requiredDate DATE,
    shippedDate DATE,
    shipVia INT,
    freight FLOAT,
    customerID VARCHAR(50),
    employeeID INT,
    FOREIGN KEY (customerID) REFERENCES Customers(customerID),
    FOREIGN KEY (employeeID) REFERENCES Employees(employeeID)
);


-- Suppliers Table
CREATE TABLE Suppliers (
    supplierID INT PRIMARY KEY,
    companyName VARCHAR(50),
    contactName VARCHAR(50),
    contactTitle VARCHAR(50)
);

-- Categories Table
CREATE TABLE Categories (
    categoryID INT PRIMARY KEY,
    categoryName VARCHAR(50)
);



-- Products Table
CREATE TABLE Products (
    productID INT PRIMARY KEY,
    productName VARCHAR(50),
    supplierID INT,
    categoryID INT,
    quantityPerUnit VARCHAR(50),
    unitPrice_1 FLOAT,
    unitsInStock INT,
    unitsOnOrder INT,
    reorderLevel INT,
    discontinued BIT,
    FOREIGN KEY (supplierID) REFERENCES Suppliers(supplierID),
    FOREIGN KEY (categoryID) REFERENCES Categories(categoryID)
);


-- OrderDetails Table (Join Table for Orders and Products)
CREATE TABLE OrderDetails (
    orderID INT,
    productID INT,
    unitPrice FLOAT,
    quantity INT,
    discount FLOAT,
    PRIMARY KEY (orderID, productID),
    FOREIGN KEY (orderID) REFERENCES Orders(orderID),
    FOREIGN KEY (productID) REFERENCES Products(productID)
);
