-- Primary Keys
ALTER TABLE Suppliers ADD CONSTRAINT PK_Suppliers PRIMARY KEY (supplierID);

ALTER TABLE OrderDetails ADD CONSTRAINT PK_OrderDetails PRIMARY KEY (orderID, productID);

ALTER TABLE Orders ADD CONSTRAINT PK_Orders PRIMARY KEY (orderID);

ALTER TABLE Categories ADD CONSTRAINT PK_Categories PRIMARY KEY (categoryID);

ALTER TABLE Products ADD CONSTRAINT PK_Products PRIMARY KEY (productID);

ALTER TABLE Employees ADD CONSTRAINT PK_Employees PRIMARY KEY (employeeID);

ALTER TABLE Customers ADD CONSTRAINT PK_Customers PRIMARY KEY (customerID);



-- Foreign Keys
ALTER TABLE Orders ADD CONSTRAINT FK_Orders_Customers FOREIGN KEY (customerID) REFERENCES Customers(customerID);

ALTER TABLE Orders ADD CONSTRAINT FK_Orders_Employees FOREIGN KEY (employeeID) REFERENCES Employees(employeeID);

ALTER TABLE OrderDetails ADD CONSTRAINT FK_OrderDetails_Orders FOREIGN KEY (orderID) REFERENCES Orders(orderID);

ALTER TABLE OrderDetails ADD CONSTRAINT FK_OrderDetails_Products FOREIGN KEY (productID) REFERENCES Products(productID);

ALTER TABLE Products ADD CONSTRAINT FK_Products_Categories FOREIGN KEY (categoryID) REFERENCES Categories(categoryID);

ALTER TABLE Products ADD CONSTRAINT FK_Products_Suppliers FOREIGN KEY (supplierID) REFERENCES Suppliers(supplierID);



-- Unique Constraints
ALTER TABLE Products ADD CONSTRAINT UQ_ProductName UNIQUE (productName);

ALTER TABLE Categories ADD CONSTRAINT UQ_CategoryName UNIQUE (categoryName);

-- Ensure NOT NULL for required fields
ALTER TABLE Suppliers ALTER COLUMN supplierID INT NOT NULL;
ALTER TABLE Customers ALTER COLUMN customerID VARCHAR(50) NOT NULL;
ALTER TABLE Employees ALTER COLUMN employeeID INT NOT NULL;
ALTER TABLE Products ALTER COLUMN productID INT NOT NULL;

-- Add CHECK constraints (example)
ALTER TABLE Products ADD CONSTRAINT CHK_UnitsInStock CHECK (unitsInStock >= 0);


