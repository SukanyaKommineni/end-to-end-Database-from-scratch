CREATE TRIGGER ReduceStockAfterOrder
ON OrderDetails
AFTER INSERT
AS
BEGIN
    UPDATE Products
    SET unitsInStock = unitsInStock - inserted.quantity
    FROM Products
    INNER JOIN inserted ON Products.productID = inserted.productID;
END;


CREATE PROCEDURE RestockProducts
AS
BEGIN
    SELECT 
        productID,
        productName,
        unitsInStock,
        reorderLevel
    FROM Products
    WHERE unitsInStock < reorderLevel;
END;
